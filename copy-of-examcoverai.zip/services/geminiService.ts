import { GoogleGenAI } from "@google/genai";
import { MODEL_NAME, generatePrompt } from "../constants";

// Helper to check for API key selection using the AI Studio helper (for paid models)
export const checkAndSelectApiKey = async (): Promise<void> => {
  const win = window as any;
  if (win.aistudio) {
    const hasKey = await win.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await win.aistudio.openSelectKey();
    }
  }
};

// Helper to process image input (File or Base64 string)
const processImageInput = async (input: File | string): Promise<{ inlineData: { data: string; mimeType: string } }> => {
  // If input is already a base64 data URL string
  if (typeof input === 'string') {
    // Expecting format: "data:image/png;base64,..."
    const parts = input.split(',');
    if (parts.length !== 2) {
      throw new Error("Invalid image data format");
    }
    const mimeMatch = parts[0].match(/:(.*?);/);
    const mimeType = mimeMatch ? mimeMatch[1] : 'image/png';
    const data = parts[1];
    return {
      inlineData: {
        data,
        mimeType
      }
    };
  }
  
  // If input is a File object
  return new Promise<{ inlineData: { data: string; mimeType: string } }>((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const result = reader.result as string;
      if (!result) {
        reject(new Error("Failed to read file"));
        return;
      }
      const base64String = result.split(',')[1];
      resolve({
        inlineData: {
          data: base64String,
          mimeType: input.type,
        },
      });
    };
    reader.onerror = reject;
    reader.readAsDataURL(input);
  });
};

export const generateCoverImage = async (
  logoInput: File | string,
  position: string,
  organization: string
): Promise<string> => {
  try {
    // Ensure we have a key selected
    await checkAndSelectApiKey();

    // Initialize API with the injected environment variable
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

    const imagePart = await processImageInput(logoInput);
    const textPrompt = generatePrompt(position, organization);

    // Call the API
    const response = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: {
        parts: [
          { text: textPrompt },
          imagePart 
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "3:4", // Closest ratio to A4 available in API
          imageSize: "2K",    // High resolution
        },
      },
    });

    // Parse response to find the image
    if (response.candidates && response.candidates[0].content.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          return `data:image/png;base64,${part.inlineData.data}`;
        }
      }
    }

    throw new Error("No image generated in the response.");

  } catch (error: any) {
    console.error("Gemini Generation Error:", error);
    
    const errorMsg = error.message || "";

    // Handle specific error cases (like API key issues or Permission Denied)
    if (errorMsg.includes("Requested entity was not found") || error.status === 403 || errorMsg.includes("Permission denied")) {
       const win = window as any;
       if (win.aistudio) {
         // If permission is denied, it often means no key or wrong key for this model.
         // Force open the key selector.
         await win.aistudio.openSelectKey();
         throw new Error("Access denied. Please select a valid paid API Key to use this model.");
       }
    }

    if (errorMsg.includes("oneof field 'data'")) {
      throw new Error("Internal Error: Invalid data structure sent to API.");
    }

    throw new Error(errorMsg || "Failed to generate image");
  }
};