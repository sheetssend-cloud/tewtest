import React from 'react';
import { BookOpen } from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="bg-gradient-to-r from-indigo-700 to-purple-700 text-white p-6 shadow-lg">
      <div className="max-w-7xl mx-auto flex items-center gap-3">
        <BookOpen className="w-8 h-8" />
        <div>
          <h1 className="text-2xl font-bold tracking-wide">ExamCoverAI</h1>
          <p className="text-sm text-indigo-100">ระบบสร้างปกหนังสือสอบราชการอัจฉริยะ</p>
        </div>
      </div>
    </header>
  );
};