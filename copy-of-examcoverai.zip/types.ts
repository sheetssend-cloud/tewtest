export interface CoverFormData {
  position: string;
  organization: string;
  logoData: string | null; // Changed from File | null to string (Base64 URL) | null
}

export interface GenerationState {
  isLoading: boolean;
  error: string | null;
  imageUrl: string | null;
}